'''
Open a file handler and read file's content in one go
'''
f_obj = open('word_list_1.txt', 'r')
#f_obj = open('word_list_2.txt', 'r')
contents = f_obj.read()
valid_words = contents.split(' ')
f_obj.close()
print(valid_words)
print("==========================================================")


def get_longest_line(f_obj):
    '''
    Given a file handler, finds the longest line in the file and returns it 
    '''
    longest_line = ""
    for line in f_obj:
        if len(line) > len(longest_line):
            longest_line = line
    return longest_line

# Get a file_name and calls get_longest_line
#f_obj = open('word_list_1.txt', 'r')
f_obj = open('word_list_1.txt', 'r')
print(f'The longest line or word is: {get_longest_line(f_obj)}')
print("==========================================================")


def give_it_a_try_write(file_name):
    '''
    Given a file_name, write to the file a specific text: "line Number \n"
    '''
    try:
        f_obj = open(file_name, 'w') # 'w' means open in 'write' mode
        for num in range(20):
            f_obj.write(f'line {num}\n')
        f_obj.close()
        print(f'Successfully wrote output to file handler {f_obj}')
        print("==========================================================")
    except OSError as e:
        print('Could not write to output due to error ', e)
        print("==========================================================")
        #print(e)

def give_it_a_try_read(file_name):
    '''
    Given a file_name, read contents of the file
    '''
    try:
        f_obj = open(file_name, 'r') # 'r' means open in 'read' mode
        contents = f_obj.read()
        valid_words = contents.split(' ')
        f_obj.close()
        print(valid_words)
        print(f'Successfully read from file "{file_name}", file handler {f_obj}')
        print("==========================================================")
    except OSError as e:
        print('Could not write to output due to error: ', e)
        print("==========================================================")
        #print(e)


def read_file_return_list(file_name):
    f_obj = open(file_name, 'r')
    contents = f_obj.read()
    valid_words = contents.split("\n")
    f_obj.close()
    print(valid_words)
    print("==========================================================")


# Force "file does not exist" error
my_file = 'word_list_111.txt'
give_it_a_try_read(my_file)

# Read an existing file (a valid one)
my_file = 'word_list_2.txt'
read_file_return_list(my_file)



